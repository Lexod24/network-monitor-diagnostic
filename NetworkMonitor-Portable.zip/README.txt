NETWORK MONITOR DIAGNOSTIC

Run: double-click NetworkMonitor.exe. No administrator access is required.
Choose Start monitoring, keep the app open while the connection problem occurs, then choose Stop and analyze. The report appears in the window and is saved with the CSV under:
%LOCALAPPDATA%\NetworkMonitor\Logs

English is selected by default. Choose Romana in the language selector for Romanian. The requested interval is 5 seconds; the report also shows the actual average time between samples.

This portable build uses local, rule-based analysis. It does not use AI, change settings, or store account credentials. The report checks gateway, Internet ICMP, three HTTPS endpoints, and three DNS domains. Read the source package README for diagnostic limits.
